import { S3Client, GetObjectCommand, PutObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import sharp from 'sharp';

const s3Client = new S3Client({ region: process.env.REGION });
const BUCKET = process.env.S3_BUCKET;

// Cache watermark on cold start
let watermarkBuffer = null;

async function getWatermark() {
  if (watermarkBuffer) return watermarkBuffer;

  const command = new GetObjectCommand({
    Bucket: BUCKET,
    Key: 'logo.png'  // Watermark is in bucket root
  });
  const response = await s3Client.send(command);
  watermarkBuffer = Buffer.from(await response.Body.transformToByteArray());
  return watermarkBuffer;
}

// Compression settings
const compressionSettings = {
  cover: { maxWidth: 1920, maxHeight: 1080, quality: 75 },
  gallery: { maxWidth: 1200, maxHeight: 800, quality: 75 },
  logo: { maxWidth: 400, maxHeight: 400, quality: 85 },
  banner: { maxWidth: 1920, maxHeight: 600, quality: 75 },
  default: { maxWidth: 1200, maxHeight: 800, quality: 75 }
};

export const handler = async (event) => {
  console.log('Processing event:', JSON.stringify(event, null, 2));

  // Fetch watermark once
  const watermark = await getWatermark();

  for (const record of event.Records) {
    const uploadKey = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));

    // Only process files in /uploads/ folder
    if (!uploadKey.startsWith('uploads/')) {
      console.log('Skipping non-upload file:', uploadKey);
      continue;
    }

    try {
      // 1. Get the uploaded image
      const getCommand = new GetObjectCommand({ Bucket: BUCKET, Key: uploadKey });
      const response = await s3Client.send(getCommand);
      const imageBuffer = Buffer.from(await response.Body.transformToByteArray());

      // 2. Determine image type from path
      let imageType = 'default';
      if (uploadKey.includes('/logo')) imageType = 'logo';
      else if (uploadKey.includes('/cover')) imageType = 'cover';
      else if (uploadKey.includes('/banner') || uploadKey.includes('/ads/')) imageType = 'banner';
      else if (uploadKey.includes('/gallery')) imageType = 'gallery';

      const settings = compressionSettings[imageType];

      // 3. Resize image
      const resizedBuffer = await sharp(imageBuffer)
        .resize(settings.maxWidth, settings.maxHeight, {
          fit: 'inside',
          withoutEnlargement: true
        })
        .toBuffer();

      // 4. Get dimensions
      const metadata = await sharp(resizedBuffer).metadata();

      // 5. Apply watermark (skip for logos)
      let finalBuffer;
      if (imageType === 'logo') {
        finalBuffer = await sharp(resizedBuffer)
          .webp({ quality: settings.quality })
          .toBuffer();
      } else {
        // Resize watermark to ~20% of image width
        const watermarkWidth = Math.floor(metadata.width * 0.2);
        const resizedWatermark = await sharp(watermark)
          .resize(watermarkWidth)
          .png()
          .toBuffer();

        // Get watermark dimensions for positioning
        const wmMeta = await sharp(resizedWatermark).metadata();
        const left = Math.floor((metadata.width - wmMeta.width) / 2);
        const top = metadata.height - wmMeta.height - 20;

        finalBuffer = await sharp(resizedBuffer)
          .composite([{
            input: resizedWatermark,
            left: left,
            top: top,
            blend: 'over'
          }])
          .webp({ quality: settings.quality })
          .toBuffer();
      }

      // 6. Generate processed key
      const processedKey = uploadKey
        .replace('uploads/', 'processed/')
        .replace(/\.[^.]+$/, '.webp');

      // 7. Upload processed image
      await s3Client.send(new PutObjectCommand({
        Bucket: BUCKET,
        Key: processedKey,
        Body: finalBuffer,
        ContentType: 'image/webp',
        CacheControl: 'public, max-age=31536000'
      }));

      // 8. Delete original
      await s3Client.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: uploadKey }));

      console.log(`✅ Processed: ${uploadKey} → ${processedKey}`);
      console.log(`   Size: ${(imageBuffer.length / 1024).toFixed(0)}KB → ${(finalBuffer.length / 1024).toFixed(0)}KB`);

    } catch (error) {
      console.error(`❌ Error processing ${uploadKey}:`, error);
      throw error;
    }
  }

  return { statusCode: 200, body: 'Processing complete' };
};
